const saveMatch = (
  match
) => {
  localStorage.setItem(
    "cricket_match",
    JSON.stringify(match)
  );

  return match;
};

const swapBatters = (
  match
) => {
  [
    match.striker,
    match.nonStriker,
  ] = [
    match.nonStriker,
    match.striker,
  ];

  [
    match.strikerRuns,
    match.nonStrikerRuns,
  ] = [
    match.nonStrikerRuns,
    match.strikerRuns,
  ];

  [
    match.strikerBalls,
    match.nonStrikerBalls,
  ] = [
    match.nonStrikerBalls,
    match.strikerBalls,
  ];
};

export const scoreboardService = {
  addRuns(match, runs) {
    const updatedMatch = {
      ...match,

      score:
        match.score + runs,
    };

    if (
      match.strikerSystem
    ) {
      updatedMatch.strikerRuns =
        match.strikerRuns +
        runs;

      updatedMatch.strikerBalls =
        match.strikerBalls +
        1;
    } else {
      updatedMatch.batterRuns =
        match.batterRuns +
        runs;

      updatedMatch.batterBalls =
        match.batterBalls +
        1;
    }

    updatedMatch.ballsInOver += 1;

    if (
      updatedMatch.ballsInOver ===
      6
    ) {
      updatedMatch.ballsInOver =
        0;

      updatedMatch.oversCompleted +=
        1;

      if (
  updatedMatch.strikerSystem
) {
  swapBatters(
    updatedMatch
  );
}
    }

   if (
  runs % 2 === 1 &&
  updatedMatch.strikerSystem
) {
  swapBatters(
    updatedMatch
  );
}

    return saveMatch(
      updatedMatch
    );
  },

  addWicket(match) {
    const updatedMatch = {
      ...match,

      wickets:
        match.wickets + 1,

      bowlerWickets:
        match.bowlerWickets +
        1,

      ballsInOver:
        match.ballsInOver + 1,
    };

    if (
      updatedMatch.ballsInOver ===
      6
    ) {
      updatedMatch.ballsInOver =
        0;

      updatedMatch.oversCompleted +=
        1;
    }

    return saveMatch(
      updatedMatch
    );
  },

  addWide(match) {
    const updatedMatch = {
      ...match,
    };

    if (
      match.wideAddsRun
    ) {
      updatedMatch.score += 1;

      updatedMatch.bowlerRuns +=
        1;
    }

    return saveMatch(
      updatedMatch
    );
  },

  addNoBall(match) {
    const updatedMatch = {
      ...match,
    };

    if (
      match.noBallAddsRun
    ) {
      updatedMatch.score += 1;

      updatedMatch.bowlerRuns +=
        1;
    }

    return saveMatch(
      updatedMatch
    );
  },

  selectNewBatter(
    match,
    playerId
  ) {
    const updatedMatch = {
      ...match,
    };

    if (
      match.strikerSystem
    ) {
      updatedMatch.striker =
        playerId;

      updatedMatch.strikerRuns =
        0;

      updatedMatch.strikerBalls =
        0;
    } else {
      updatedMatch.singleBatter =
        playerId;

      updatedMatch.batterRuns =
        0;

      updatedMatch.batterBalls =
        0;
    }

    return saveMatch(
      updatedMatch
    );
  },

  selectNewBowler(
    match,
    playerId
  ) {
    const updatedMatch = {
      ...match,

      currentBowler:
        playerId,

      bowlerRuns: 0,

      bowlerWickets: 0,
    };

    return saveMatch(
      updatedMatch
    );
  },

  isInningsComplete(
    match
  ) {
    return (
      match.oversCompleted >=
      match.overs
    );
  },
};