import { useState } from "react";

import Footer from "../components/Footer";
import { matchService } from "../services/matchService";
import { scoreboardService }
from "../services/scoreboardService";

import "./Scoreboard.css";

function Scoreboard() {
  const [match, setMatch] =
    useState(
      matchService.getMatch()
    );

  if (!match) {
    return (
      <>
        <div className="scoreboard-page">
          <h2>
            No Match Found
          </h2>
        </div>

        <Footer />
      </>
    );
  }

  const players =
    JSON.parse(
      localStorage.getItem(
        "cricket_data"
      )
    )?.players || [];

  const getPlayerName = (
    playerId
  ) => {
    const player =
      players.find(
        (p) =>
          p.id === playerId
      );

    return (
      player?.name ||
      "Unknown Player"
    );
  };

  const saveMatchState = (
    updatedMatch
  ) => {
    matchService.saveMatch(
      updatedMatch
    );

    setMatch(updatedMatch);
  };

  

  const inningsComplete =
    match.oversCompleted >=
    match.overs;

  const battingTeam =
    match.battingFirst ===
    match.teamA.id
      ? match.teamA
      : match.teamB;


      const refreshMatch = () => {
  setMatch(
    matchService.getMatch()
  );
};

  return (
    <>
      <div className="scoreboard-page">
        <div className="match-banner">
          <h2>
            {
              battingTeam.name
            }
          </h2>
        </div>

        <div className="score-card">
          <h1>
            {match.score}/
            {match.wickets}
          </h1>

          <p>
            Overs{" "}
            {
              match.oversCompleted
            }
            .
            {
              match.ballsInOver
            }
            {" / "}
            {match.overs}
          </p>
        </div>

        {match.strikerSystem ? (
          <div className="players-card">
            <div>
              <span>
                Striker
              </span>

              <strong>
                {getPlayerName(
                  match.striker
                )}
              </strong>

              <p>
                {
                  match.strikerRuns
                }
                (
                {
                  match.strikerBalls
                }
                )
              </p>
            </div>

            <div>
              <span>
                Non-Striker
              </span>

              <strong>
                {getPlayerName(
                  match.nonStriker
                )}
              </strong>

              <p>
                {
                  match.nonStrikerRuns
                }
                (
                {
                  match.nonStrikerBalls
                }
                )
              </p>
            </div>
          </div>
        ) : (
          <div className="players-card">
            <div>
              <span>
                Batter
              </span>

              <strong>
                {getPlayerName(
                  match.singleBatter
                )}
              </strong>

              <p>
                {
                  match.batterRuns
                }
                (
                {
                  match.batterBalls
                }
                )
              </p>
            </div>
          </div>
        )}

        <div className="innings-card">
          <h3>
            Bowler
          </h3>

          <strong>
            {getPlayerName(
              match.currentBowler
            )}
          </strong>

          <p>
            Runs:
            {" "}
            {
              match.bowlerRuns
            }

            {" | "}

            Wickets:
            {" "}
            {
              match.bowlerWickets
            }
          </p>
        </div>

        {inningsComplete ? (
          <div className="innings-card">
            <h2>
              🏁 Innings
              Complete
            </h2>
          </div>
        ) : (
          <>
            <div className="action-grid">
              <button
                onClick={() => {
  scoreboardService.addRuns(
    match,
    0
  );

  refreshMatch();
}}
              >
                0
              </button>

              <button
                onClick={() => {
  scoreboardService.addRuns(
    match,
    1
  );

  refreshMatch();
}}
              >
                1
              </button>

              <button
                onClick={() => {
  scoreboardService.addRuns(
    match,
    2
  );

  refreshMatch();
}}
              >
                2
              </button>

              <button
                onClick={() => {
  scoreboardService.addRuns(
    match,
    3
  );

  refreshMatch();
}}
              >
                3
              </button>

              <button
                onClick={() => {
  scoreboardService.addRuns(
    match,
    4
  );

  refreshMatch();
}}
              >
                4
              </button>

              <button
                onClick={() => {
  scoreboardService.addRuns(
    match,
    6
  );

  refreshMatch();
}}
              >
                6
              </button>
            </div>

            <div className="extra-grid">
              <button
                onClick={() => {
  scoreboardService.addWicket(
    match
  );

  refreshMatch();
}}
              >
                W
              </button>

              <button
                onClick={() => {
  scoreboardService.addWide(
    match
  );

  refreshMatch();
}}
              >
                WD
              </button>

              <button
                onClick={() => {
  scoreboardService.addNoBall(
    match
  );

  refreshMatch();
}}
              >
                NB
              </button>
            </div>
          </>
        )}
      </div>

      <Footer />
    </>
  );
}

export default Scoreboard;